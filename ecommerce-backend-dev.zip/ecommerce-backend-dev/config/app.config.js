exports.config={
    PORT:9014,
    MONGO_URL: "mongodb+srv://sai:sai@ecommerce.obdec.mongodb.net/7amecommerce?retryWrites=true&w=majority",
    JWT_SECRET:'bdkvkdbkjdbv'
}